{-# LANGUAGE OverloadedStrings #-}

module Main where

import Lib
import Control.Monad.Reader
import Control.Monad.Writer
import Random
import qualified Data.Text as T

maxNum = 50

data CustomWord = Attempt String | MainWord String deriving Show

instance Eq CustomWord where
    (Attempt word1) == (MainWord word2) = word1 == word2
    (MainWord word1) == (Attempt word2) = word1 == word2
    (Attempt word1) == (Attempt word2) = word1 == word2
    (MainWord word1) == (MainWord word2) = word1 == word2


words :: [String]
words = [
    "ask",
    "be",
    "become",
    "begin",
    "call",
    "can",
    "come",
    "could",
    "do",
    "feel",
    "find",
    "get",
    "give",
    "go",
    "have",
    "hear",
    "help",
    "keep",
    "know",
    "leave",
    "let",
    "like",
    "live",
    "look",
    "make",
    "may",
    "mean",
    "might",
    "move",
    "need",
    "play",
    "put",
    "run",
    "say",
    "see",
    "seem",
    "should",
    "show",
    "start",
    "take",
    "talk",
    "tell",
    "think",
    "try",
    "turn",
    "use",
    "want",
    "will",
    "work",
    "would"]


-- create a random generator with the specified seed value
getRandomGen :: Int -> StdGen
getRandomGen seed = mkStdGen seed


-- If a seed is specified, use it; otherwise, pick a random one
-- This is a little ugly: a seed is initially in the form ["123"],
-- which is how it's represented as an argument to the program
getSeed :: [String] -> IO Int
getSeed [] = getRandomSeed
getSeed (x:_) = return $ read x

-- Use the pre-seeded random generator to get a random seed
-- for another random generator if none was specified by the user.
-- This is needed as I couldn't find a way to get the seed
-- out of an existing random generator (such as the system one),
-- yet I needed to be able to tell the user what the seed was,
-- so that the game would be repeatable.
getRandomSeed :: IO Int
getRandomSeed = do 
    randomSrc <- getStdGen
    return $ fst $ Random.random $ randomSrc





buildLogs :: CustomWord -> Writer [String] CustomWord
buildLogs (Attempt word) = writer (Attempt word, ["Got Attempt: " ++ word])
buildLogs (MainWord word) = writer (MainWord word, ["Got MainWord: " ++ word])


areEqual :: CustomWord -> CustomWord -> Writer [String] Bool
areEqual word attemptWord = do
    loggedWord <- buildLogs word
    loggedAttemptWord <- buildLogs attemptWord
    return (loggedWord == loggedAttemptWord)


getBool :: (Bool, [String]) -> Bool
getBool (bool, list) = bool


getLog :: (Bool, [String]) -> [String]
getLog (bool, list) = list

printLogs :: [String] -> IO ()
printLogs list = do
    putStrLn $ show list


processGuessWord :: CustomWord -> Reader String (Bool, [String])
processGuessWord mainWord = do
    attemptWord <- ask
    let result = runWriter $ areEqual mainWord (Attempt attemptWord)
    -- obtener el string con pistas
    return result


guessWord :: CustomWord -> Int -> IO Bool
guessWord mainWord numAttemps = do
    attemptWord <- getLine
    let result = runReader (processGuessWord mainWord) attemptWord
    let boolResult = getBool result
    let logResult = getLog result

    putStrLn $ show logResult

    if numAttemps == 0 then return False
    else if (not)boolResult then do
        putStrLn $ "Wrong attempt"
        guessWord mainWord (numAttemps - 1)
    else    
        return True


finish :: T.Text
finish = "Thanks for playing"


main :: IO ()
main = do
    seed <- getSeed
    putStrLn $ show seed
    putStrLn $ "Add a wodasrd:"
    word <- getLine
    result <- guessWord (MainWord word) 3
    putStrLn $ show result